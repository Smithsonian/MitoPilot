
<!-- README.md is generated from README.Rmd. Please edit that file -->

# `{MitoPilot}`

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

# Overview

`{MitoPilot}` is a package for the assembly and annotation of
mitochondrial genomes from genome skimming data.

# Installation

You can install the development version of `{MitoPilot}` from GitHub:

``` r
devtools::install_github("JonahVentures/MitoPilot")
```

Alternatively, you can clone this repository and install the package
locally from the project folder:

``` r
devtools::install()
```

# Usage

A `{MitoPilot}` project can be created using the `init()` function. This
function will create a new project directory (or update an existing
directory) with the necessary files and directories to run the pipeline.
A path to a mapping file is required to create a project and must
minimally include a column to serve as a unique identifier for each
sample and columns providing the forward and reverse raw paired-read
input files, `R1` and `R2`, respectively. The default Nextflow executor
must also be specified when initializing a project to populate the
`.config` file. Currently only the `local` and `awsbatch` executors are
supported. After project initialization, please review the `.config`
file in the project directory to ensure that the all necissary
parameters are provided (missing values will be indicated with
placeholders in the format, \<<SOMETHING_HERE>\>).

An example project can be created to test the pipeline installation:

``` r
init_test_project(
  path = "MitoPilot-test",
  executor = "local"
)
```

This function will load pre-filtered data sets for relatively quick
testing of the pipeline. Alternatively, you can set the parameter
`full_size=TRUE` to download all raw data for the test assemblies from
ENA (though you should be prepared to wait a while).

Currently, running the pipeline requires the use of the Nextflow command
line interface. A helper function `update_mitopilot()` is provided to
show the nextflow command needed to update the pipeline from the
terminal.
